import pandas as pd
def p(d):
    print(d)

fileName = "C:\\Users\\gautap\\Desktop\\testdata\\pokemon_data.csv"
df = pd.read_csv(fileName)