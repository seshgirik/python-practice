def showData01():
    print ("im from show.")

def showData02():
    print ("im from show.")

def showData04():
    print ("im from show.")

def showData05():
    print ("im from show.")


name = "pawan"